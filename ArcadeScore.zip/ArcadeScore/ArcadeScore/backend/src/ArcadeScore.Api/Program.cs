using ArcadeScore.Api.Repositories;
using ArcadeScore.Api.Services;

const string CorsPolicyName = "Frontend";

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddSingleton<IScoreRepository, InMemoryScoreRepository>();
builder.Services.AddScoped<IScoreService, ScoreService>();

var allowedOrigins = builder.Configuration.GetSection("AllowedOrigins").Get<string[]>()
                     ?? new[] { "http://localhost:4200" };

builder.Services.AddCors(options =>
    options.AddPolicy(CorsPolicyName, policy =>
        policy.WithOrigins(allowedOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod()));

var app = builder.Build();

if (app.Configuration.GetValue<bool>("SeedSampleData"))
{
    using var scope = app.Services.CreateScope();
    SampleDataSeeder.Seed(scope.ServiceProvider.GetRequiredService<IScoreService>());
}

app.UseCors(CorsPolicyName);
app.MapControllers();

app.Run();
