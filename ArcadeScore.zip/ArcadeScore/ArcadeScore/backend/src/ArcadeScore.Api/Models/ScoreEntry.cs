namespace ArcadeScore.Api.Models;

/// <summary>Uma partida registrada: quem jogou, quantos pontos fez e quando.</summary>
public sealed record ScoreEntry(int Id, string Player, int Points, DateOnly PlayedOn);
