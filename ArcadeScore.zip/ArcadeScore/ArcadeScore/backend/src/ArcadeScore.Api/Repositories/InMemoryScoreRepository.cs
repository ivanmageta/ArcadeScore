using ArcadeScore.Api.Models;

namespace ArcadeScore.Api.Repositories;

/// <summary>Repositório em memória</summary>
public sealed class InMemoryScoreRepository : IScoreRepository
{
    private readonly List<ScoreEntry> _entries = new();
    private readonly object _lock = new();
    private int _nextId = 1;

    public ScoreEntry Add(string player, int points, DateOnly playedOn)
    {
        lock (_lock)
        {
            var entry = new ScoreEntry(_nextId++, player, points, playedOn);
            _entries.Add(entry);
            return entry;
        }
    }

    public ScoreEntry? GetById(int id)
    {
        lock (_lock)
        {
            return _entries.FirstOrDefault(e => e.Id == id);
        }
    }

    public IReadOnlyList<ScoreEntry> GetAll()
    {
        lock (_lock)
        {
            return _entries.ToList();
        }
    }

    public IReadOnlyList<ScoreEntry> GetByPlayer(string player)
    {
        lock (_lock)
        {
            return _entries
                .Where(e => string.Equals(e.Player, player, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
    }
}
