using ArcadeScore.Api.Models;

namespace ArcadeScore.Api.Repositories;

public interface IScoreRepository
{
    ScoreEntry Add(string player, int points, DateOnly playedOn);

    ScoreEntry? GetById(int id);

    IReadOnlyList<ScoreEntry> GetAll();

    IReadOnlyList<ScoreEntry> GetByPlayer(string player);
}
