using ArcadeScore.Api.Dtos;
using ArcadeScore.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace ArcadeScore.Api.Controllers;

[ApiController]
[Route("api/players")]
public sealed class PlayersController : ControllerBase
{
    private readonly IScoreService _service;

    public PlayersController(IScoreService service)
    {
        _service = service;
    }

    /// <summary>Estatísticas de um jogador (partidas, média, maior/menor pontuação, recordes e tempo de jogo).</summary>
    [HttpGet("{name}/statistics")]
    [ProducesResponseType(typeof(PlayerStatisticsDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public ActionResult<PlayerStatisticsDto> GetStatistics(string name)
    {
        var statistics = _service.GetPlayerStatistics(name);

        if (statistics is null)
        {
            return NotFound(new ProblemDetails
            {
                Status = StatusCodes.Status404NotFound,
                Title = "Jogador não encontrado",
                Detail = $"Não há partidas registradas para o jogador \"{name}\"."
            });
        }

        return statistics;
    }
}
