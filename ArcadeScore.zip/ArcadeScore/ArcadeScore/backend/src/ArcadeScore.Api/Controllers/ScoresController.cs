using ArcadeScore.Api.Dtos;
using ArcadeScore.Api.Models;
using ArcadeScore.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace ArcadeScore.Api.Controllers;

[ApiController]
[Route("api/scores")]
public sealed class ScoresController : ControllerBase
{
    private readonly IScoreService _service;

    public ScoresController(IScoreService service)
    {
        _service = service;
    }

    /// <summary>Registra a pontuação de uma partida.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ScoreEntry), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public ActionResult<ScoreEntry> Register(CreateScoreRequest request)
    {
        // Responde 400 se a validação do modelo falhar.
		// Validação dos campos obrigatórios.
        var entry = _service.Register(request.Player!, request.Points!.Value, request.PlayedOn!.Value);

        return CreatedAtAction(nameof(GetById), new { id = entry.Id }, entry);
    }

    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ScoreEntry), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public ActionResult<ScoreEntry> GetById(int id)
    {
        var entry = _service.GetById(id);

        if (entry is null)
        {
            return NotFound();
        }

        return entry;
    }

    /// <summary>As 10 melhores pontuações registradas.</summary>
    [HttpGet("ranking")]
    [ProducesResponseType(typeof(IReadOnlyList<RankingEntryDto>), StatusCodes.Status200OK)]
    public ActionResult<IReadOnlyList<RankingEntryDto>> GetRanking()
        => Ok(_service.GetRanking());
}
