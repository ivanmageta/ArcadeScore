namespace ArcadeScore.Api.Dtos;

public sealed record PlayerStatisticsDto(
    string Player,
    int GamesPlayed,
    double AverageScore,
    int HighestScore,
    int LowestScore,
    int RecordBreaks,
    DateOnly FirstGameDate,
    DateOnly LastGameDate,
    int PlayTimeDays);
