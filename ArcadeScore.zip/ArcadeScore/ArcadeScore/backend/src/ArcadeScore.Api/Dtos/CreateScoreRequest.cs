using System.ComponentModel.DataAnnotations;

namespace ArcadeScore.Api.Dtos;

public sealed class CreateScoreRequest : IValidatableObject
{
    [Required(ErrorMessage = "Informe a data da partida.")]
    public DateOnly? PlayedOn { get; init; }

    [Required(ErrorMessage = "Informe a pontuação.")]
    [Range(0, int.MaxValue, ErrorMessage = "A pontuação deve ser um número inteiro maior ou igual a zero.")]
    public int? Points { get; init; }

    [Required(ErrorMessage = "Informe o jogador.")]
    [StringLength(PlayerRules.MaxLength, ErrorMessage = "O nome do jogador deve ter no máximo {1} caracteres.")]
    [RegularExpression(PlayerRules.Pattern, ErrorMessage = "Use apenas letras, números, espaço, hífen ou sublinhado no nome do jogador.")]
    public string? Player { get; init; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        var limit = DateOnly.FromDateTime(DateTime.Today).AddDays(1);

        if (PlayedOn > limit)
        {
            yield return new ValidationResult(
                "A data da partida não pode estar no futuro.",
                new[] { nameof(PlayedOn) });
        }
    }
}
