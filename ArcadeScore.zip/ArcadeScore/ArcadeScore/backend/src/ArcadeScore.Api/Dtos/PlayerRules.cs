namespace ArcadeScore.Api.Dtos;

/// <summary>Regras de formato do nome do jogador (as mesmas são aplicadas no front-end).</summary>
public static class PlayerRules
{
    public const int MaxLength = 20;

    //Evita caracteres problemáticos em URLs.
    public const string Pattern = @"^[A-Za-z0-9À-ÿ _-]+$";
}
