namespace ArcadeScore.Api.Dtos;

public sealed record RankingEntryDto(int Position, string Player, int Points, DateOnly PlayedOn);
