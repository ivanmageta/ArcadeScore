namespace ArcadeScore.Api.Services;

/// <summary>Popula a API com partidas ficticias.</summary>
public static class SampleDataSeeder
{
    private static readonly string[] Players =
        { "7LN", "PKN", "UDK", "NGC", "PWT", "ETC", "WGH", "CVA", "KKK", "DKB" };

    public static void Seed(IScoreService service)
    {
        var random = new Random(2026);
        var today = DateOnly.FromDateTime(DateTime.Today);

        foreach (var player in Players)
        {
            var games = random.Next(8, 25);
            var start = today.AddDays(-random.Next(60, 240));
            var step = Math.Max(1, (today.DayNumber - start.DayNumber) / games);

            for (var i = 0; i < games; i++)
            {
                service.Register(player, random.Next(3_000, 16_000), start.AddDays(i * step));
            }
        }
    }
}
