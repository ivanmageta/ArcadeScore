using ArcadeScore.Api.Dtos;
using ArcadeScore.Api.Models;
using ArcadeScore.Api.Repositories;

namespace ArcadeScore.Api.Services;

public sealed class ScoreService : IScoreService
{
    public const int DefaultRankingSize = 10;

    private readonly IScoreRepository _repository;

    public ScoreService(IScoreRepository repository)
    {
        _repository = repository;
    }

    public ScoreEntry Register(string player, int points, DateOnly playedOn)
        => _repository.Add(NormalizePlayer(player), points, playedOn);

    public ScoreEntry? GetById(int id) => _repository.GetById(id);

    public IReadOnlyList<RankingEntryDto> GetRanking(int top = DefaultRankingSize)
    {
        // Em caso de empate, vence quem fez a pontuação primeiro.
        return _repository.GetAll()
            .OrderByDescending(e => e.Points)
            .ThenBy(e => e.PlayedOn)
            .ThenBy(e => e.Id)
            .Take(top)
            .Select((e, index) => new RankingEntryDto(index + 1, e.Player, e.Points, e.PlayedOn))
            .ToList();
    }

    public PlayerStatisticsDto? GetPlayerStatistics(string player)
    {
        var normalized = NormalizePlayer(player);
        var entries = _repository.GetByPlayer(normalized);

        return entries.Count == 0
            ? null
            : PlayerStatisticsCalculator.Calculate(normalized, entries);
    }

    /// <summary>Tranformação case string.</summary>
    private static string NormalizePlayer(string player) => player.Trim().ToUpperInvariant();
}
