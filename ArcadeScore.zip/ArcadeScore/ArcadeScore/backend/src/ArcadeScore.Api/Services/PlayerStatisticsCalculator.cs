using ArcadeScore.Api.Dtos;
using ArcadeScore.Api.Models;

namespace ArcadeScore.Api.Services;

/// <summary>Cálculo das estatísticas de um jogador.</summary>
public static class PlayerStatisticsCalculator
{
    public static PlayerStatisticsDto Calculate(string player, IReadOnlyCollection<ScoreEntry> entries)
    {
        if (entries.Count == 0)
        {
            throw new ArgumentException("É necessário ao menos uma partida.", nameof(entries));
        }

        // A ordem do Id desempata partidas do mesmo dia.
        var chronological = entries
            .OrderBy(e => e.PlayedOn)
            .ThenBy(e => e.Id)
            .ToList();

        var firstGame = chronological[0].PlayedOn;
        var lastGame = chronological[^1].PlayedOn;

        return new PlayerStatisticsDto(
            Player: player,
            GamesPlayed: chronological.Count,
            AverageScore: Math.Round(chronological.Average(e => (double)e.Points), 2),
            HighestScore: chronological.Max(e => e.Points),
            LowestScore: chronological.Min(e => e.Points),
            RecordBreaks: CountRecordBreaks(chronological),
            FirstGameDate: firstGame,
            LastGameDate: lastGame,
            PlayTimeDays: lastGame.DayNumber - firstGame.DayNumber);
    }

    /// <summary>Conta as partidas cuja pontuação superou a maior pontuação anterior.</summary>
    private static int CountRecordBreaks(IReadOnlyList<ScoreEntry> chronological)
    {
        var breaks = 0;
        var best = chronological[0].Points;

        for (var i = 1; i < chronological.Count; i++)
        {
            if (chronological[i].Points > best)
            {
                best = chronological[i].Points;
                breaks++;
            }
        }

        return breaks;
    }
}
