using ArcadeScore.Api.Dtos;
using ArcadeScore.Api.Models;

namespace ArcadeScore.Api.Services;

public interface IScoreService
{
    ScoreEntry Register(string player, int points, DateOnly playedOn);

    ScoreEntry? GetById(int id);

    /// <summary>As melhores pontuações registradas, da maior para a menor.</summary>
    IReadOnlyList<RankingEntryDto> GetRanking(int top = ScoreService.DefaultRankingSize);

    /// <summary>Estatísticas do jogador, ou null se ele não tiver partidas registradas.</summary>
    PlayerStatisticsDto? GetPlayerStatistics(string player);
}
