import { HttpErrorResponse } from '@angular/common/http';

/** Converte um erro HTTP em mensagens amigáveis (inclui os erros de validação da API). */
export function extractErrors(error: HttpErrorResponse): string[] {
  if (error.status === 0) {
    return ['Não foi possível conectar à API. Verifique se o back-end está em execução.'];
  }

  const body = error.error;

  if (body && body.errors) {
    const messages: string[] = [];
    Object.keys(body.errors).forEach(field => {
      messages.push(...body.errors[field]);
    });
    if (messages.length) {
      return messages;
    }
  }

  if (body && body.detail) {
    return [body.detail];
  }

  return ['Não foi possível concluir a operação. Tente novamente.'];
}
