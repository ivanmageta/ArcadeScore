import { AbstractControl, ValidationErrors } from '@angular/forms';

export interface DateParts {
  year: number;
  month: number; // 1-12
  day: number;
}

function pad(value: number): string {
  return ('0' + value).slice(-2);
}

/** Data de hoje (fuso local) no formato yyyy-MM-dd, o mesmo de <input type="date">. */
export function todayIso(): string {
  const now = new Date();
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

/** Lê "yyyy-MM-dd" sem passar por Date, evitando surpresas de fuso horário. */
export function parseIsoDate(value: string): DateParts | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value || '');
  return match ? { year: +match[1], month: +match[2], day: +match[3] } : null;
}

/** Validador: a data da partida não pode estar no futuro. */
export function notFutureDate(control: AbstractControl): ValidationErrors | null {
  const value = control.value as string;
  return value && value > todayIso() ? { futureDate: true } : null;
}
