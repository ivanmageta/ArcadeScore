import { Pipe, PipeTransform } from '@angular/core';

import { parseIsoDate } from './date-utils';

/**
 * Descreve o período entre a primeira e a última partida em linguagem natural.
 * Ex.: "Menos de 1 dia", "12 dias", "3 meses", "1 ano e 2 meses".
 */
@Pipe({ name: 'playTime' })
export class PlayTimePipe implements PipeTransform {
  transform(firstDate: string, lastDate: string): string {
    const first = parseIsoDate(firstDate);
    const last = parseIsoDate(lastDate);

    if (!first || !last) {
      return '—';
    }

    let months = (last.year - first.year) * 12 + (last.month - first.month);
    if (last.day < first.day) {
      months--;
    }

    if (months < 1) {
      const msPerDay = 24 * 60 * 60 * 1000;
      const days = Math.round(
        (Date.UTC(last.year, last.month - 1, last.day) -
          Date.UTC(first.year, first.month - 1, first.day)) / msPerDay);

      if (days < 1) {
        return 'Menos de 1 dia';
      }
      return days === 1 ? '1 dia' : `${days} dias`;
    }

    const years = Math.floor(months / 12);
    const remainingMonths = months % 12;

    const monthsText = remainingMonths === 1 ? '1 mês' : `${remainingMonths} meses`;
    if (years === 0) {
      return monthsText;
    }

    const yearsText = years === 1 ? '1 ano' : `${years} anos`;
    return remainingMonths === 0 ? yearsText : `${yearsText} e ${monthsText}`;
  }
}
