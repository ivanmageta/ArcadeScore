export interface ScoreEntry {
  id: number;
  player: string;
  points: number;
  playedOn: string; // yyyy-MM-dd
}

export interface RegisterScoreRequest {
  playedOn: string; // yyyy-MM-dd
  points: number;
  player: string;
}

export interface RankingEntry {
  position: number;
  player: string;
  points: number;
  playedOn: string;
}

export interface PlayerStatistics {
  player: string;
  gamesPlayed: number;
  averageScore: number;
  highestScore: number;
  lowestScore: number;
  recordBreaks: number;
  firstGameDate: string;
  lastGameDate: string;
  playTimeDays: number;
}
