import { registerLocaleData } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import localePt from '@angular/common/locales/pt';
import { LOCALE_ID, NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlayerStatsComponent } from './pages/player-stats/player-stats.component';
import { RankingComponent } from './pages/ranking/ranking.component';
import { ScoreFormComponent } from './pages/score-form/score-form.component';
import { PlayTimePipe } from './shared/play-time.pipe';

registerLocaleData(localePt);

@NgModule({
  declarations: [
    AppComponent,
    ScoreFormComponent,
    RankingComponent,
    PlayerStatsComponent,
    PlayTimePipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'pt' }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
