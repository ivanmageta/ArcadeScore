import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';
import { PlayerStatistics, RankingEntry, RegisterScoreRequest, ScoreEntry } from '../models/arcade.models';

@Injectable({ providedIn: 'root' })
export class ArcadeApiService {
  private readonly baseUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  registerScore(request: RegisterScoreRequest): Observable<ScoreEntry> {
    return this.http.post<ScoreEntry>(`${this.baseUrl}/scores`, request);
  }

  getRanking(): Observable<RankingEntry[]> {
    return this.http.get<RankingEntry[]>(`${this.baseUrl}/scores/ranking`);
  }

  getPlayerStatistics(player: string): Observable<PlayerStatistics> {
    return this.http.get<PlayerStatistics>(
      `${this.baseUrl}/players/${encodeURIComponent(player)}/statistics`);
  }
}
