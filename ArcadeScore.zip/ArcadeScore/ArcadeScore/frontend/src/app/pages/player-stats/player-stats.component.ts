import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, EventEmitter, HostListener, Input, OnInit, Output, ViewChild } from '@angular/core';

import { PlayerStatistics } from '../../models/arcade.models';
import { ArcadeApiService } from '../../services/arcade-api.service';
import { extractErrors } from '../../shared/http-errors';

@Component({
  selector: 'app-player-stats',
  templateUrl: './player-stats.component.html'
})
export class PlayerStatsComponent implements OnInit, AfterViewInit {
  @Input() player: string;
  @Output() closed = new EventEmitter<void>();

  @ViewChild('closeButton') closeButton: ElementRef<HTMLButtonElement>;

  stats: PlayerStatistics | null = null;
  loading = true;
  error = '';

  constructor(private api: ArcadeApiService) { }

  ngOnInit(): void {
    this.api.getPlayerStatistics(this.player).subscribe(
      stats => {
        this.stats = stats;
        this.loading = false;
      },
      (error: HttpErrorResponse) => {
        this.error = extractErrors(error)[0];
        this.loading = false;
      }
    );
  }

  ngAfterViewInit(): void {
    this.closeButton.nativeElement.focus();
  }

  @HostListener('document:keydown.escape')
  close(): void {
    this.closed.emit();
  }
}
