import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { RegisterScoreRequest } from '../../models/arcade.models';
import { ArcadeApiService } from '../../services/arcade-api.service';
import { notFutureDate, todayIso } from '../../shared/date-utils';
import { extractErrors } from '../../shared/http-errors';

/** Mesmas regras do back-end*/
const PLAYER_MAX_LENGTH = 20;
const PLAYER_PATTERN = '[A-Za-z0-9À-ÿ _-]+';

@Component({
  selector: 'app-score-form',
  templateUrl: './score-form.component.html'
})
export class ScoreFormComponent {
  readonly today = todayIso();
  readonly playerMaxLength = PLAYER_MAX_LENGTH;

  form: FormGroup;
  saving = false;
  successMessage = '';
  errors: string[] = [];

  constructor(private fb: FormBuilder, private api: ArcadeApiService) {
    this.form = this.fb.group({
      playedOn: [this.today, [Validators.required, notFutureDate]],
      points: [null, [Validators.required, Validators.min(0), Validators.max(2147483647), Validators.pattern('[0-9]+')]],
      player: ['', [Validators.required, Validators.maxLength(PLAYER_MAX_LENGTH), Validators.pattern(PLAYER_PATTERN)]]
    });
  }

  get playedOn(): AbstractControl { return this.form.get('playedOn'); }
  get points(): AbstractControl { return this.form.get('points'); }
  get player(): AbstractControl { return this.form.get('player'); }

  showError(control: AbstractControl): boolean {
    return control.invalid && (control.touched || control.dirty);
  }

  submit(): void {
    this.successMessage = '';
    this.errors = [];

    if (this.form.invalid) {
      Object.keys(this.form.controls).forEach(name => this.form.get(name).markAsTouched());
      return;
    }

    const value = this.form.value;
    const request: RegisterScoreRequest = {
      playedOn: value.playedOn,
      points: Number(value.points),
      player: String(value.player).trim()
    };

    this.saving = true;
    this.api.registerScore(request).subscribe(
      entry => {
        this.saving = false;
        this.successMessage =
          `Pontuação de ${entry.points.toLocaleString('pt-BR')} pontos registrada para ${entry.player}.`;
        this.form.reset({ playedOn: request.playedOn, points: null, player: '' });
      },
      (error: HttpErrorResponse) => {
        this.saving = false;
        this.errors = extractErrors(error);
      }
    );
  }
}
