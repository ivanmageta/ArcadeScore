import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

import { RankingEntry } from '../../models/arcade.models';
import { ArcadeApiService } from '../../services/arcade-api.service';
import { extractErrors } from '../../shared/http-errors';

@Component({
  selector: 'app-ranking',
  templateUrl: './ranking.component.html'
})
export class RankingComponent implements OnInit {
  ranking: RankingEntry[] = [];
  loading = true;
  error = '';
  selectedPlayer: string | null = null;

  constructor(private api: ArcadeApiService) { }

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.error = '';

    this.api.getRanking().subscribe(
      ranking => {
        this.ranking = ranking;
        this.loading = false;
      },
      (error: HttpErrorResponse) => {
        this.error = extractErrors(error)[0];
        this.loading = false;
      }
    );
  }

  openStats(player: string): void {
    this.selectedPlayer = player;
  }

  closeStats(): void {
    this.selectedPlayer = null;
  }

  trackByPosition(_: number, entry: RankingEntry): number {
    return entry.position;
  }
}
