import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RankingComponent } from './pages/ranking/ranking.component';
import { ScoreFormComponent } from './pages/score-form/score-form.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'registrar' },
  { path: 'registrar', component: ScoreFormComponent },
  { path: 'ranking', component: RankingComponent },
  { path: '**', redirectTo: 'registrar' }
];

@NgModule({
  // useHash: funciona em qualquer hospedagem estática, sem configurar fallback de rotas.
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
